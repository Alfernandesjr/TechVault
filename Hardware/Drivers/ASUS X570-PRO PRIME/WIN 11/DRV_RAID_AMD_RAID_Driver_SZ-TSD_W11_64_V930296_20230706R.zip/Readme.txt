If you only build SATA RAID, please use “SATA_RAID” RAID driver.
If you build NVME RAID or NVME+SATA RAID, please use “NVME_CC” RAID driver.
